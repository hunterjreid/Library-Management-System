/********************************************************************************
** Form generated from reading UI file 'createaccountdialog.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATEACCOUNTDIALOG_H
#define UI_CREATEACCOUNTDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_createAccountDialog
{
public:
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_5;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *emailLn;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLineEdit *usernameLn;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *firstnameLn;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *passwordLn;
    QPushButton *createAccountBtn;
    QPushButton *pushButton_2;
    QCheckBox *checkBox;

    void setupUi(QDialog *createAccountDialog)
    {
        if (createAccountDialog->objectName().isEmpty())
            createAccountDialog->setObjectName(QString::fromUtf8("createAccountDialog"));
        createAccountDialog->resize(388, 639);
        createAccountDialog->setMinimumSize(QSize(388, 639));
        createAccountDialog->setMaximumSize(QSize(388, 639));
        verticalLayout_3 = new QVBoxLayout(createAccountDialog);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        groupBox = new QGroupBox(createAccountDialog);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(110, 150, 176, 183));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_2->addWidget(label_5);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        emailLn = new QLineEdit(layoutWidget);
        emailLn->setObjectName(QString::fromUtf8("emailLn"));

        horizontalLayout->addWidget(emailLn);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        usernameLn = new QLineEdit(layoutWidget);
        usernameLn->setObjectName(QString::fromUtf8("usernameLn"));

        horizontalLayout_4->addWidget(usernameLn);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        firstnameLn = new QLineEdit(layoutWidget);
        firstnameLn->setObjectName(QString::fromUtf8("firstnameLn"));

        horizontalLayout_2->addWidget(firstnameLn);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        passwordLn = new QLineEdit(layoutWidget);
        passwordLn->setObjectName(QString::fromUtf8("passwordLn"));

        horizontalLayout_3->addWidget(passwordLn);


        verticalLayout->addLayout(horizontalLayout_3);


        verticalLayout_2->addLayout(verticalLayout);

        createAccountBtn = new QPushButton(layoutWidget);
        createAccountBtn->setObjectName(QString::fromUtf8("createAccountBtn"));

        verticalLayout_2->addWidget(createAccountBtn);

        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(90, 460, 75, 23));
        checkBox = new QCheckBox(groupBox);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(60, 380, 181, 17));

        verticalLayout_3->addWidget(groupBox);


        retranslateUi(createAccountDialog);
        QObject::connect(pushButton_2, &QPushButton::clicked, createAccountDialog, qOverload<>(&QDialog::close));

        QMetaObject::connectSlotsByName(createAccountDialog);
    } // setupUi

    void retranslateUi(QDialog *createAccountDialog)
    {
        createAccountDialog->setWindowTitle(QCoreApplication::translate("createAccountDialog", "Dialog", nullptr));
        groupBox->setTitle(QString());
        label_5->setText(QCoreApplication::translate("createAccountDialog", "SIGN UP!", nullptr));
        label->setText(QCoreApplication::translate("createAccountDialog", "Email :", nullptr));
        label_4->setText(QCoreApplication::translate("createAccountDialog", "Username", nullptr));
        label_2->setText(QCoreApplication::translate("createAccountDialog", "First Name", nullptr));
        label_3->setText(QCoreApplication::translate("createAccountDialog", "Password", nullptr));
        createAccountBtn->setText(QCoreApplication::translate("createAccountDialog", "create account", nullptr));
        pushButton_2->setText(QCoreApplication::translate("createAccountDialog", "Back", nullptr));
        checkBox->setText(QCoreApplication::translate("createAccountDialog", "Show Password", nullptr));
    } // retranslateUi

};

namespace Ui {
    class createAccountDialog: public Ui_createAccountDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATEACCOUNTDIALOG_H
