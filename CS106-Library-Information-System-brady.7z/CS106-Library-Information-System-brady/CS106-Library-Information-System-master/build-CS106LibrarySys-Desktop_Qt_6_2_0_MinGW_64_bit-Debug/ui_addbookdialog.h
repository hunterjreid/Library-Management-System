/********************************************************************************
** Form generated from reading UI file 'addbookdialog.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDBOOKDIALOG_H
#define UI_ADDBOOKDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addBookDialog
{
public:
    QLabel *label_5;
    QPushButton *confirmBtn;
    QLabel *label_6;
    QPushButton *addImageBtn;
    QLabel *imagePreview;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *TitleLn;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *authorLn;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *genreLn;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QPlainTextEdit *wordsRaw;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_5;
    QRadioButton *radio_yes;
    QRadioButton *radioButton_2;

    void setupUi(QDialog *addBookDialog)
    {
        if (addBookDialog->objectName().isEmpty())
            addBookDialog->setObjectName(QString::fromUtf8("addBookDialog"));
        addBookDialog->resize(640, 480);
        label_5 = new QLabel(addBookDialog);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 20, 351, 16));
        confirmBtn = new QPushButton(addBookDialog);
        confirmBtn->setObjectName(QString::fromUtf8("confirmBtn"));
        confirmBtn->setGeometry(QRect(180, 430, 75, 23));
        label_6 = new QLabel(addBookDialog);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(20, 340, 70, 17));
        addImageBtn = new QPushButton(addBookDialog);
        addImageBtn->setObjectName(QString::fromUtf8("addImageBtn"));
        addImageBtn->setGeometry(QRect(370, 20, 201, 23));
        imagePreview = new QLabel(addBookDialog);
        imagePreview->setObjectName(QString::fromUtf8("imagePreview"));
        imagePreview->setGeometry(QRect(370, 70, 201, 341));
        layoutWidget = new QWidget(addBookDialog);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 50, 304, 280));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        TitleLn = new QLineEdit(layoutWidget);
        TitleLn->setObjectName(QString::fromUtf8("TitleLn"));

        horizontalLayout->addWidget(TitleLn);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        authorLn = new QLineEdit(layoutWidget);
        authorLn->setObjectName(QString::fromUtf8("authorLn"));

        horizontalLayout_2->addWidget(authorLn);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        genreLn = new QLineEdit(layoutWidget);
        genreLn->setObjectName(QString::fromUtf8("genreLn"));

        horizontalLayout_3->addWidget(genreLn);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        wordsRaw = new QPlainTextEdit(layoutWidget);
        wordsRaw->setObjectName(QString::fromUtf8("wordsRaw"));

        horizontalLayout_4->addWidget(wordsRaw);


        verticalLayout->addLayout(horizontalLayout_4);

        layoutWidget1 = new QWidget(addBookDialog);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(110, 340, 160, 19));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        radio_yes = new QRadioButton(layoutWidget1);
        radio_yes->setObjectName(QString::fromUtf8("radio_yes"));

        horizontalLayout_5->addWidget(radio_yes);

        radioButton_2 = new QRadioButton(layoutWidget1);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));

        horizontalLayout_5->addWidget(radioButton_2);


        retranslateUi(addBookDialog);

        QMetaObject::connectSlotsByName(addBookDialog);
    } // setupUi

    void retranslateUi(QDialog *addBookDialog)
    {
        addBookDialog->setWindowTitle(QCoreApplication::translate("addBookDialog", "Dialog", nullptr));
        label_5->setText(QCoreApplication::translate("addBookDialog", "add a book to datavbase", nullptr));
        confirmBtn->setText(QCoreApplication::translate("addBookDialog", "add", nullptr));
        label_6->setText(QCoreApplication::translate("addBookDialog", "Checkoutable?", nullptr));
        addImageBtn->setText(QCoreApplication::translate("addBookDialog", "add book cover", nullptr));
        imagePreview->setText(QString());
        label->setText(QCoreApplication::translate("addBookDialog", "Title : ", nullptr));
        label_2->setText(QCoreApplication::translate("addBookDialog", "Author :", nullptr));
        label_3->setText(QCoreApplication::translate("addBookDialog", "Genre :", nullptr));
        label_4->setText(QCoreApplication::translate("addBookDialog", "Words :", nullptr));
        radio_yes->setText(QCoreApplication::translate("addBookDialog", "Yes", nullptr));
        radioButton_2->setText(QCoreApplication::translate("addBookDialog", "No", nullptr));
    } // retranslateUi

};

namespace Ui {
    class addBookDialog: public Ui_addBookDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDBOOKDIALOG_H
