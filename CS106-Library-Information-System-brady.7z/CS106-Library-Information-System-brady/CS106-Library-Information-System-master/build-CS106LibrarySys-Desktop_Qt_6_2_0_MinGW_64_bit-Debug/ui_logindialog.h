/********************************************************************************
** Form generated from reading UI file 'logindialog.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINDIALOG_H
#define UI_LOGINDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_loginDialog
{
public:
    QGridLayout *gridLayout;
    QGroupBox *groupBox;
    QWidget *layoutWidget;
    QFormLayout *formLayout;
    QLabel *emailLb;
    QLineEdit *emailLn;
    QLabel *passwordLb;
    QLineEdit *passwordLn;
    QPushButton *confrimBtn;
    QPushButton *backBtn;
    QCheckBox *showPassCheckbox;

    void setupUi(QDialog *loginDialog)
    {
        if (loginDialog->objectName().isEmpty())
            loginDialog->setObjectName(QString::fromUtf8("loginDialog"));
        loginDialog->resize(388, 639);
        gridLayout = new QGridLayout(loginDialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        groupBox = new QGroupBox(loginDialog);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMaximumSize(QSize(370, 16777215));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(40, 130, 211, 106));
        formLayout = new QFormLayout(layoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        emailLb = new QLabel(layoutWidget);
        emailLb->setObjectName(QString::fromUtf8("emailLb"));

        formLayout->setWidget(0, QFormLayout::LabelRole, emailLb);

        emailLn = new QLineEdit(layoutWidget);
        emailLn->setObjectName(QString::fromUtf8("emailLn"));

        formLayout->setWidget(0, QFormLayout::FieldRole, emailLn);

        passwordLb = new QLabel(layoutWidget);
        passwordLb->setObjectName(QString::fromUtf8("passwordLb"));

        formLayout->setWidget(1, QFormLayout::LabelRole, passwordLb);

        passwordLn = new QLineEdit(layoutWidget);
        passwordLn->setObjectName(QString::fromUtf8("passwordLn"));

        formLayout->setWidget(1, QFormLayout::FieldRole, passwordLn);

        confrimBtn = new QPushButton(layoutWidget);
        confrimBtn->setObjectName(QString::fromUtf8("confrimBtn"));

        formLayout->setWidget(2, QFormLayout::FieldRole, confrimBtn);

        backBtn = new QPushButton(layoutWidget);
        backBtn->setObjectName(QString::fromUtf8("backBtn"));

        formLayout->setWidget(3, QFormLayout::SpanningRole, backBtn);

        showPassCheckbox = new QCheckBox(groupBox);
        showPassCheckbox->setObjectName(QString::fromUtf8("showPassCheckbox"));
        showPassCheckbox->setGeometry(QRect(70, 360, 191, 17));

        gridLayout->addWidget(groupBox, 0, 0, 1, 1);


        retranslateUi(loginDialog);
        QObject::connect(backBtn, &QPushButton::clicked, loginDialog, qOverload<>(&QDialog::close));

        QMetaObject::connectSlotsByName(loginDialog);
    } // setupUi

    void retranslateUi(QDialog *loginDialog)
    {
        loginDialog->setWindowTitle(QCoreApplication::translate("loginDialog", "Dialog", nullptr));
        groupBox->setTitle(QString());
        emailLb->setText(QCoreApplication::translate("loginDialog", "Username", nullptr));
        passwordLb->setText(QCoreApplication::translate("loginDialog", "Password", nullptr));
        confrimBtn->setText(QCoreApplication::translate("loginDialog", "Signin", nullptr));
        backBtn->setText(QCoreApplication::translate("loginDialog", "Back", nullptr));
        showPassCheckbox->setText(QCoreApplication::translate("loginDialog", "Show Password", nullptr));
    } // retranslateUi

};

namespace Ui {
    class loginDialog: public Ui_loginDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINDIALOG_H
