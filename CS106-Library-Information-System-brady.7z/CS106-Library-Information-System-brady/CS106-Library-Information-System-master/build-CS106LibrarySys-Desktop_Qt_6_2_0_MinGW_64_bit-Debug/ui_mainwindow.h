/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label_6;
    QPushButton *addBookAdmin;
    QLabel *bookPreview;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QListWidget *listWidget_books;
    QWidget *widget1;
    QVBoxLayout *verticalLayout;
    QLabel *titleLabel;
    QLabel *authLabel;
    QPlainTextEdit *bookContentPlain;
    QWidget *widget2;
    QVBoxLayout *verticalLayout_2;
    QPushButton *createAccountBtn;
    QLabel *label;
    QPushButton *loginBtn;
    QPushButton *signOutBtn;
    QLabel *loginLb;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1280, 720);
        MainWindow->setMinimumSize(QSize(1280, 720));
        MainWindow->setMaximumSize(QSize(1280, 720));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(30, 10, 531, 61));
        addBookAdmin = new QPushButton(centralwidget);
        addBookAdmin->setObjectName(QString::fromUtf8("addBookAdmin"));
        addBookAdmin->setGeometry(QRect(180, 630, 301, 23));
        bookPreview = new QLabel(centralwidget);
        bookPreview->setObjectName(QString::fromUtf8("bookPreview"));
        bookPreview->setGeometry(QRect(520, 210, 221, 401));
        bookPreview->setStyleSheet(QString::fromUtf8("border: 1px solid black;"));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(180, 250, 306, 371));
        horizontalLayout_2 = new QHBoxLayout(widget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        listWidget_books = new QListWidget(widget);
        new QListWidgetItem(listWidget_books);
        new QListWidgetItem(listWidget_books);
        new QListWidgetItem(listWidget_books);
        listWidget_books->setObjectName(QString::fromUtf8("listWidget_books"));
        listWidget_books->setAlternatingRowColors(true);

        horizontalLayout_2->addWidget(listWidget_books);

        widget1 = new QWidget(centralwidget);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(770, 290, 258, 232));
        verticalLayout = new QVBoxLayout(widget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        titleLabel = new QLabel(widget1);
        titleLabel->setObjectName(QString::fromUtf8("titleLabel"));

        verticalLayout->addWidget(titleLabel);

        authLabel = new QLabel(widget1);
        authLabel->setObjectName(QString::fromUtf8("authLabel"));

        verticalLayout->addWidget(authLabel);

        bookContentPlain = new QPlainTextEdit(widget1);
        bookContentPlain->setObjectName(QString::fromUtf8("bookContentPlain"));

        verticalLayout->addWidget(bookContentPlain);

        widget2 = new QWidget(centralwidget);
        widget2->setObjectName(QString::fromUtf8("widget2"));
        widget2->setGeometry(QRect(60, 110, 122, 121));
        verticalLayout_2 = new QVBoxLayout(widget2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        createAccountBtn = new QPushButton(widget2);
        createAccountBtn->setObjectName(QString::fromUtf8("createAccountBtn"));

        verticalLayout_2->addWidget(createAccountBtn);

        label = new QLabel(widget2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(160000, 16777215));

        verticalLayout_2->addWidget(label);

        loginBtn = new QPushButton(widget2);
        loginBtn->setObjectName(QString::fromUtf8("loginBtn"));

        verticalLayout_2->addWidget(loginBtn);

        signOutBtn = new QPushButton(widget2);
        signOutBtn->setObjectName(QString::fromUtf8("signOutBtn"));

        verticalLayout_2->addWidget(signOutBtn);

        loginLb = new QLabel(widget2);
        loginLb->setObjectName(QString::fromUtf8("loginLb"));

        verticalLayout_2->addWidget(loginLb);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1280, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);
        QObject::connect(listWidget_books, &QListWidget::currentTextChanged, titleLabel, &QLabel::setText);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "SYSTEM", nullptr));
        addBookAdmin->setText(QCoreApplication::translate("MainWindow", "add book (NEW) admin only ", nullptr));
        bookPreview->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "All Books", nullptr));

        const bool __sortingEnabled = listWidget_books->isSortingEnabled();
        listWidget_books->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = listWidget_books->item(0);
        ___qlistwidgetitem->setText(QCoreApplication::translate("MainWindow", "ewqewq", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = listWidget_books->item(1);
        ___qlistwidgetitem1->setText(QCoreApplication::translate("MainWindow", "ewqeqw", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = listWidget_books->item(2);
        ___qlistwidgetitem2->setText(QCoreApplication::translate("MainWindow", "ewqewq2", nullptr));
        listWidget_books->setSortingEnabled(__sortingEnabled);

        titleLabel->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        authLabel->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        createAccountBtn->setText(QCoreApplication::translate("MainWindow", "Create Account", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Profile Settings | Status :", nullptr));
        loginBtn->setText(QCoreApplication::translate("MainWindow", "Login", nullptr));
        signOutBtn->setText(QCoreApplication::translate("MainWindow", "Sign out", nullptr));
        loginLb->setText(QCoreApplication::translate("MainWindow", "Not logged in", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
