#ifndef USER_H
#define USER_H
#include <iostream>
#include <bits/stdc++.h>
using namespace std;

class user
{
protected:
    string Name;
    string Email;
    string Password;
public:
    user(string name, string email, string password);
    user();
    // ========== Setters ==========
    void setName(string name);
    void setEmail(string email);
    void setPassword(string password);
    // ========== Getters ==========
    string getName();
    string getEmail();
    string getPassword();
    void showInfo();
    bool operator == (user&); // in searching compare name(or id) and passwords

};

#endif // USER_H
