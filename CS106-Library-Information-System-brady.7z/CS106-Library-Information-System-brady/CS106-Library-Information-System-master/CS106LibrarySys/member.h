#ifndef MEMBER_H
#define MEMBER_H
#include <bits/stdc++.h>
#include "user.h"
#include "book.h"
#include "database.h"

class member : public user
{
private:
    vector<book> currentBooks;
    string currentBook_name;
    string requestedBook_name;
    vector<string> borrowedBooks_names;
public:
    member();
    member(string name, string email, string password);
    // setters and adders
    //overloaded functions
    void setCurrentBook(string);
    void setRequestedBook(string);
    void addBorrowedBooks(vector<string>);
    void showInfo();

    // getters
    string getCurrentBookName();
    vector<book> getCurrentBookVector(database*);
    string getRequestedBookName();
    vector<string> getSearchHistory();

};

#endif // MEMBER_H
