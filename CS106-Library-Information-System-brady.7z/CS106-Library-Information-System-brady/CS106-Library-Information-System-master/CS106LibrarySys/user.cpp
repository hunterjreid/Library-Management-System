#include "user.h"

user::user()
{

}

user::user(string name , string email , string password)
{
    Name  = name ;
    Email = email ;
    Password = password ;
}

void user::setName(string name)
{
    Name = name ;
}
void user::setEmail(string email)
{
    Email = email ;
}
void user::setPassword(string password)
{
    Password = password ;
}

string user::getName()
{
    return this->Name ;
}
string user::getEmail()
{
    return this->Email ;
}
string user::getPassword()
{
    return Password ;
}

void user::showInfo()
{
    cout <<"Your info : "<<endl;
    cout << "Name : " << Name << endl << "E-mail : " << Email << endl;
}
