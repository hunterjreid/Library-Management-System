#ifndef DATABASE_H
#define DATABASE_H
#include <bits/stdc++.h>
#include <iostream>
#include "user.h"

class database
{
public:
    database();
};

#endif // DATABASE_H
