#include "member.h"

member::member() : user()
{

}

member::member(string name, string password, string email) : user(name,email,password)
{

}

void member::showInfo()
{
    cout <<"User's info : "<<endl;
    cout << "Name : " << Name << endl << "E-mail : " << Email << endl;
    cout << endl;
    cout << "current:" << currentBook_name << " ,requested:" << requestedBook_name << endl;
}

void member::setCurrentBook(string name)
{
    this->currentBook_name = name;
}

void member::setRequestedBook(string name)
{
    this->requestedBook_name = name;
}

string member::getCurrentBookName()
{
    return this->currentBook_name;
}

vector<book> member::getCurrentBookVector(database *db)
{
    vector<string> v= this->split_string(currentBook_name,",");
}
