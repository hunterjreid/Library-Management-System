#ifndef ADMIN_H
#define ADMIN_H
#include <bits/stdc++.h>
#include "user.h"
#include "book.h"
#include "database.h"
#include "member.h"

class book;

class admin : public user
{
private:
    int flag,bookState;
public:
    admin();
    admin(string name, string email, string password);
    void showInfo();
    void addBook(book* Published_Book);
    void RemoveBook(book* Removed_Book);
    void addBook(string Published_Book);
    void RemoveBook(string Removed_Book);
    bool checkState(book*);
};

#endif // ADMIN_H
