#include "admin.h"

admin::admin()
{

}
