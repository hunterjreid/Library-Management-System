## CS106-Library-Information-System
# A Yoobee project by Brady, Hunter and Seluvaia📚

***qt 5.12 c++17***


Manage your libaray books more efficantly than ever with our .... system, With Login/Account Creation and an advanced book management system with features like Add Book, Remove Book its sure to meet all your libary needs with capcaity off 500,000+ books!

Features:
Login/Account Creation Book Management Create Edit

todos: Bool Remove Clone Modify| Fliter: Date, Authour, Topic Search by keyword
security todos:
  - LOGIN password must be 6 letters and contain 1 number
  - LOGIN emails must be legit emails
  - LOGIN emails can not be already taken
  - LOGIN usernames cannot be taken
